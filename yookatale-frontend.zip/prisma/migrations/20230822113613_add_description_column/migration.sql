-- AlterTable
ALTER TABLE "Payment" ADD COLUMN "description" TEXT;
