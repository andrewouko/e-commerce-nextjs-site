-- AlterTable
ALTER TABLE "Payment" ADD COLUMN "callback" TEXT;
