//import React from "react";

const SettingsTab = () => {
  return <div>SettingsTab</div>;
};

export default SettingsTab;
