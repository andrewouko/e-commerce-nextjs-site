//import React from 'react'

const SubscriptionsTab = () => {
  return <div>SubscriptionsTab</div>;
};

export default SubscriptionsTab;
