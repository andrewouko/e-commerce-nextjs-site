const PROD_DB_URL = "https://yookatale-server-app.onrender.com/api";
const DEV_DB_URL = "http://localhost:8000/api";

export const DB_URL = PROD_DB_URL;
